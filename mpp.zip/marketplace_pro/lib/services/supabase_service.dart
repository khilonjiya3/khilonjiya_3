// This file has been consolidated into lib/utils/supabase_service.dart
// Please remove this file and use the implementation in utils/ folder instead

// Redirect to the main implementation
export '../utils/supabase_service.dart';
